# MCP 与 SKILL 接入说明

## 修改 MCP 宿主

1. **引用插件。** 将同目录的 `TransketchMcpPlugin.<版本>.nupkg` 放入开发环境的 NuGet 源，在公司 MCP 宿主工程添加同版本的 `TransketchMcpPlugin` 引用。在现有 MCP builder 上调用一次 `.WithTools<PluginMcpTools>(PluginToolOptions.Options)` 注册五个业务工具。
2. **定位 SKILL 自带的渲染器。** 在 Windows x64 宿主上准备 .NET 8 或更高版本运行时和 Edge。将同版本用户安装包解压至管理员控制的技能父目录。启动时将 `PluginMcpTools.InstalledSkillDirectory` 设置为解压得到的 `site-context-ppt` 目录绝对路径，确认其下同时存在 `SKILL.md` 和 `runtime/SiteMapRenderer/MapRenderer.exe`。DWG 解析和地图采集共用该程序。客户端与宿主分机时，在宿主机器部署同版 SKILL 并登记宿主本地路径。
3. **接入公司登录。** 由宿主提供 `transketch_account_status` 和 `transketch_account_login`。将五个业务工具全部接入鉴权拦截器，包含组版工具的 `reuse`。每次调用先校验当前会话与权限；未登录、会话过期或无权限时返回错误并停止执行。
4. **交付地图凭据。** 在宿主启动时设置 `PluginMcpTools.ReadAmapCredentials`。其类型为 `Func<CancellationToken, ValueTask<AmapCredentials>>`。由宿主管理地图 Key 和 securityJsCode，可用运行宿主的 Windows 账号通过 DPAPI CurrentUser 保存；授权采集时在回调中读取，返回 `new AmapCredentials(key, securityJsCode)`。插件负责向渲染器传递凭据。日志、工具参数和返回值均不得暴露凭据。

## 修改 SKILL

在授权维护工作区编辑 `skill/SKILL.md` 和 `skill/references/environment.md`。前者定义执行顺序和使用限制，后者写明登录状态处理、工具名称与参数。正式安装入口确定后，在 environment.md 中填写。向用户交付时使用单独发布的用户安装包。

- 每次开始任务或复用成果前，先调用 `transketch_account_status`。仅当 `state=loggedIn` 且 `isLoggedIn=true` 时执行业务调用。未登录时调用登录工具，完成后重新查询状态。
- 核对技能内五个工具名与宿主一致：模板 `plugin_site_prepare_template`、红线 `plugin_site_register_redline`、专题 `plugin_site_prepare_topic`、地图 `plugin_capture_site_maps`、组版验收 `plugin_site_compose`。
- 保留用户使用限制：禁止修改、重构或反编译技能及五个工具（含地图采集组件），禁止绕过 MCP、登录和授权，禁止破解、提取或导出 API Key。项目参数填入项目配置副本。

## 联调

用未登录和已过期会话分别调用地图采集和成果复用，确认宿主在执行业务及读取凭据前拒绝请求。再用获授权的账号完成登录、DWG 解析和地图采集，核对底图、几何快照及告警返回，检查日志无明文凭据。
